import React, { useState, useRef, useEffect } from 'react';
import { Heart, Music, Pause, Play, Volume2 } from 'lucide-react';

export default function App() {
  const [showQuestion, setShowQuestion] = useState(true);
  const [noButtonPosition, setNoButtonPosition] = useState({ x: 0, y: 0 });
  const [isNoButtonFixed, setIsNoButtonFixed] = useState(false);
  const [showPlayer, setShowPlayer] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [noAttempts, setNoAttempts] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const noButtonRef = useRef<HTMLButtonElement>(null);
  const yesButtonRef = useRef<HTMLButtonElement>(null);
  const teleportAudioRef = useRef<HTMLAudioElement>(null);
  const yesAudioRef = useRef<HTMLAudioElement>(null);
  const musicAudioRef = useRef<HTMLAudioElement>(null);

  // ═══════════════════════════════════════════════════════════
  // 🎵 CUSTOMIZATION SECTION - CHANGE THESE VALUES!
  // ═══════════════════════════════════════════════════════════
  
  const BACKGROUND_IMAGE = 'https://images.unsplash.com/photo-1579606629359-304b021e7cb9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaW5rJTIwaGVhcnRzJTIwcm9tYW50aWMlMjB2YWxlbnRpbmVzfGVufDF8fHx8MTc3MDkxMTI2Nnww&ixlib=rb-4.1.0&q=80&w=1080';
  
  // Sound Effects
  const TELEPORT_SOUND = 'https://www.myinstants.com/media/sounds/vine-boom.mp3'; 
  const YES_SOUND = 'https://www.myinstants.com/media/sounds/mlg-airhorn.mp3'; 
  
  // 🎵 MUSIC PLAYER - Change these to customize your music!
  const MUSIC_URL = 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'; 
  // Other music examples you can try:
  // 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'
  // 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3'
  // Or use any direct MP3 URL!
  
  const ALBUM_COVER = 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=400&fit=crop';
  // Other album cover examples:
  // 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=400&h=400&fit=crop' (vinyl)
  // 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=400&h=400&fit=crop' (concert)
  // Or use any image URL!
  
  const SONG_TITLE = 'You Are My Valentine';
  const ARTIST_NAME = 'Forever Yours';
  
  // ═══════════════════════════════════════════════════════════'

  // Audio event handlers - ensure state stays synced
  useEffect(() => {
    const audio = musicAudioRef.current;
    if (!audio) return;

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleEnded = () => setIsPlaying(false);
    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleLoadedMetadata = () => setDuration(audio.duration);

    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);

    // Set initial volume
    audio.volume = volume;

    return () => {
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
    };
  }, [volume]);

  useEffect(() => {
    if (noButtonRef.current && yesButtonRef.current) {
      const yesRect = yesButtonRef.current.getBoundingClientRect();
      setNoButtonPosition({ 
        x: yesRect.right + 24,
        y: yesRect.top
      });
    }
  }, []);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!showQuestion || !noButtonRef.current) return;

    const rect = noButtonRef.current.getBoundingClientRect();
    const buttonCenterX = rect.left + rect.width / 2;
    const buttonCenterY = rect.top + rect.height / 2;
    const distance = Math.sqrt(
      Math.pow(e.clientX - buttonCenterX, 2) + 
      Math.pow(e.clientY - buttonCenterY, 2)
    );

    if (distance < 120) {
      if (!isNoButtonFixed) {
        setIsNoButtonFixed(true);
      }
      teleportNoButton();
    }
  };

  const teleportNoButton = () => {
    if (!noButtonRef.current) return;
    
    const buttonRect = noButtonRef.current.getBoundingClientRect();
    const buttonWidth = buttonRect.width;
    const buttonHeight = buttonRect.height;
    const padding = 20;
    
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    
    const maxX = viewportWidth - buttonWidth - padding;
    const maxY = viewportHeight - buttonHeight - padding;
    const minX = padding;
    const minY = padding;
    
    if (maxX <= minX || maxY <= minY) return;
    
    const newX = Math.random() * (maxX - minX) + minX;
    const newY = Math.random() * (maxY - minY) + minY;
    
    setNoButtonPosition({ x: newX, y: newY });
    setNoAttempts(prev => prev + 1);
    
    if (teleportAudioRef.current) {
      teleportAudioRef.current.currentTime = 0;
      teleportAudioRef.current.play().catch(err => console.log('Audio play failed:', err));
    }
  };

  const handleYesClick = () => {
    setShowQuestion(false);
    
    if (yesAudioRef.current) {
      yesAudioRef.current.currentTime = 0;
      yesAudioRef.current.play().catch(err => console.log('Audio play failed:', err));
    }
    
    setTimeout(() => {
      setShowPlayer(true);
      setIsPlaying(true);
      // Start playing music
      if (musicAudioRef.current) {
        musicAudioRef.current.play().catch(err => console.log('Music play failed:', err));
      }
    }, 500);
  };

  const togglePlayPause = () => {
    if (!musicAudioRef.current) return;
    
    if (isPlaying) {
      musicAudioRef.current.pause();
    } else {
      musicAudioRef.current.play().catch(err => console.log('Music play failed:', err));
    }
    setIsPlaying(!isPlaying);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (musicAudioRef.current) {
      musicAudioRef.current.volume = newVolume;
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!musicAudioRef.current || !duration) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    const newTime = percentage * duration;
    
    musicAudioRef.current.currentTime = newTime;
    setCurrentTime(newTime);
  };

  // Dynamic messages based on attempts
  const getMessage = () => {
    if (noAttempts === 0) return "💕";
    if (noAttempts < 3) return "Please? 🥺";
    if (noAttempts < 5) return "Pretty please? 💖";
    if (noAttempts < 8) return "I'll take that as a yes! 😊";
    return "You can't resist forever! 💝";
  };

  return (
    <div 
      className="min-h-screen w-full flex items-center justify-center p-4 relative overflow-hidden"
      style={{
        backgroundImage: `url(${BACKGROUND_IMAGE})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
      onMouseMove={handleMouseMove}
    >
      <audio ref={teleportAudioRef} src={TELEPORT_SOUND} preload="auto" />
      <audio ref={yesAudioRef} src={YES_SOUND} preload="auto" />
      <audio 
        ref={musicAudioRef} 
        src={MUSIC_URL} 
        preload="auto"
        loop
      /> 
      
      {/* Simple gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-pink-400/20 via-transparent to-purple-400/20" />

      {/* Question Card */}
      {showQuestion && (
        <div className="relative z-10 backdrop-blur-xl bg-white/15 border border-white/30 rounded-[2.5rem] p-12 shadow-2xl max-w-lg w-full text-center transition-all duration-300">
          
          {/* Animated Heart */}
          <div className="mb-6 inline-block">
            <Heart 
              className="w-20 h-20 text-pink-500 fill-pink-500 drop-shadow-lg transition-all duration-300" 
              style={{
                transform: `scale(${1 + noAttempts * 0.08})`,
                filter: `drop-shadow(0 0 ${10 + noAttempts * 2}px rgba(236, 72, 153, 0.6))`
              }}
            />
          </div>
          
          {/* Question */}
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-3 drop-shadow-lg">
            Will you be my Valentine?
          </h1>
          
          {/* Dynamic message */}
          <p className="text-xl text-pink-100 mb-8 h-8 transition-all duration-300">
            {getMessage()}
          </p>
          
          {/* Buttons */}
          <div className="flex gap-4 justify-center items-center">
            <button
              ref={yesButtonRef}
              onClick={handleYesClick}
              className="px-10 py-4 bg-pink-500 hover:bg-pink-600 text-white rounded-full font-bold text-xl shadow-lg hover:shadow-pink-500/50 transition-all hover:scale-110 active:scale-95"
              style={{
                transform: `scale(${1 + noAttempts * 0.05})`,
              }}
            >
              Yes! 💖
            </button>
            
            <button
              ref={noButtonRef}
              style={
                isNoButtonFixed
                  ? {
                      position: 'fixed',
                      left: `${noButtonPosition.x}px`,
                      top: `${noButtonPosition.y}px`,
                      transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
                      transform: `scale(${Math.max(0.6, 1 - noAttempts * 0.05)})`
                    }
                  : {}
              }
              className="px-10 py-4 bg-gray-400 hover:bg-gray-500 text-white rounded-full font-bold text-xl shadow-lg"
            >
              No
            </button>
          </div>
        </div>
      )}

      {/* Music Player */}
      {showPlayer && (
        <div className="relative z-10 backdrop-blur-xl bg-white/15 border border-white/30 rounded-[2.5rem] p-8 shadow-2xl max-w-md w-full">
          
          {/* Album Cover */}
          <div className="relative mb-6 group">
            <div className="w-full aspect-square rounded-2xl overflow-hidden shadow-xl">
              <img 
                src={ALBUM_COVER} 
                alt="Album Cover" 
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              />
            </div>
            {/* Vinyl effect when playing */}
            {isPlaying && (
              <div className="absolute inset-0 rounded-2xl border-4 border-pink-400/30 animate-spin-slow pointer-events-none" />
            )}
          </div>
          
          {/* Song Info */}
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-white mb-1">{SONG_TITLE}</h2>
            <p className="text-pink-100">{ARTIST_NAME}</p>
          </div>
          
          {/* Progress Bar */}
          <div className="mb-6">
            <div 
              className="h-1.5 bg-white/20 rounded-full overflow-hidden cursor-pointer"
              onClick={handleSeek}
            >
              <div 
                className="h-full bg-pink-500 rounded-full transition-all duration-100"
                style={{ 
                  width: `${duration ? (currentTime / duration) * 100 : 0}%`
                }}
              />
            </div>
            <div className="flex justify-between text-xs text-white/70 mt-2">
              <span>{currentTime ? new Date(currentTime * 1000).toISOString().substr(14, 5) : '0:00'}</span>
              <span>{duration ? new Date(duration * 1000).toISOString().substr(14, 5) : '0:00'}</span>
            </div>
          </div>
          
          {/* Play Button */}
          <div className="flex justify-center mb-6">
            <button 
              onClick={togglePlayPause}
              className="w-16 h-16 bg-white rounded-full flex items-center justify-center hover:scale-110 transition-all shadow-lg hover:shadow-pink-500/30"
            >
              {isPlaying ? (
                <Pause className="w-7 h-7 text-pink-500 fill-pink-500" />
              ) : (
                <Play className="w-7 h-7 text-pink-500 fill-pink-500 ml-1" />
              )}
            </button>
          </div>
          
          {/* Volume */}
          <div className="flex items-center justify-center gap-3 mb-6">
            <Volume2 className="w-5 h-5 text-white/70" />
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={volume}
              onChange={handleVolumeChange}
              className="w-32 accent-pink-500 cursor-pointer"
            />
          </div>
          
          {/* Success Message */}
          <div className="text-center bg-white/10 rounded-2xl p-6 backdrop-blur-sm">
            <div className="text-3xl mb-2">🎉💕✨</div>
            <p className="text-white font-semibold text-lg">
              Yay! Happy Valentine's Day!
            </p>
            <p className="text-pink-100 text-sm mt-1">
              You made my day special 💖
            </p>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes spin-slow {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
        
        .animate-spin-slow {
          animation: spin-slow 3s linear infinite;
        }
      `}</style>
    </div>
  );
}